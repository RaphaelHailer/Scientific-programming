#!/bin/bash
#SBATCH --job-name=Optimization
#SBATCH --output=/home/a02884/Salome_meca/Fichiers_de_commande_Theo/Optimization/output_files/Optimization.o%j
#SBATCH --error=/home/a02884/Salome_meca/Fichiers_de_commande_Theo/Optimization/output_files/Optimization.e%j
#SBATCH --mem=300000
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=24
#SBATCH --time=4320
#SBATCH --partition=an
#SBATCH --wckey=P11YB:ASTER --exclusive --cpus-per-task=1 --threads-per-core=1 --distribution=block:block --mem-bind=local
##SBATCH --qos=cn_asterhpc_rd

srun python3 optimization_cube.py
