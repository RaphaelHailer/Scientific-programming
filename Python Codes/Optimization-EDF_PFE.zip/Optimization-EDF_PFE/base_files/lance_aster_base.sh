#!/bin/bash
#SBATCH --job-name=Optimization
#SBATCH --output=/home/a02884/Salome_meca/Fichiers_de_commande_Theo/Optimization/output_files/Optimization.o%j
#SBATCH --error=/home/a02884/Salome_meca/Fichiers_de_commande_Theo/Optimization/output_files/Optimization.e%j
#SBATCH --mem=300000
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=24
#SBATCH --time=5

#SBATCH --wckey=P11YB:ASTER --exclusive --cpus-per-task=1 --threads-per-core=1 --distribution=block:block --mem-bind=local
##SBATCH --qos=cn_asterhpc_rd


. /software/restricted/simumeca/aster/install/stable-updates/share/aster/profile.sh
# . /software/restricted/simumeca/aster/install/unstable/share/aster/profile.sh
#. ~/dev/codeaster/install/mpi/share/aster/profile.sh
#. /scratch/users/d15779/code_aster/install/share/aster/profile.sh

# mpirun -np ${SLURM_NPROCS} --tag-output --mca mpi_warn_on_fork 0 /software/restricted/simumeca/aster/install/stable-updates/mpi/bin/run_aster cube_sensibi_@N@_@E@_@R@.export --only-proc0
mpirun -np ${SLURM_NPROCS} --tag-output --mca mpi_warn_on_fork 0 /software/restricted/simumeca/aster/install/stable-updates/bin/run_aster INSERT_EXPORT_DIR --only-proc0
#mpirun -np ${SLURM_NPROCS} --tag-output --mca mpi_warn_on_fork 0 ~/dev/codeaster/install/mpi/bin/run_aster eq_excavation.export
