import os
import numpy as np 
import opt_module as opt
from datetime import datetime
import time
import random
import pandas as pd
''' 
optimization algorithm to study the cube cycles of mechanical stress using the Zhang parameters of the Chaboche constitutive law
'''

######## OPTIMIZATION SECTION - DATA NECESSARY ###############
wdir = '/home/a02884/Salome_meca/Fichiers_de_commande_Theo/Optimization' #INSERT HERE THE PATH TO THE Optimization DIRECTORY
epsilon_list = [0.003,0.005,0.006] # INSERT HERE THE LIST OF STRAIN AMPLITUDES TO STUDY


eps_str = []
for i in range(len(epsilon_list)):
    eps_str.append(str(round(epsilon_list[i]*100,2))+'%')

exp_dir = wdir
filename = 'experimental_300C_HC.xlsx'
res_dir = os.path.join(wdir,'results_ZHANG')



def compute_RMSE(individual):

    ######### DIRECTORIES CONFIGURATION
    print(individual)
    time.sleep(random.uniform(0,5))
    now = datetime.now() 
    now = now.strftime("%d-%m_%H-%M-%S-%f")
    wdir = os.getcwd() #'/home/a02884/Salome_meca/Fichiers_de_commande_Theo/Optimization'
    base_dir = os.path.join(wdir,'base_files')

    base_comm_name = 'etude_test_ZHANG_Base.comm'
    comm_opt_name = f'{now}-etude_test_ZHANG_opt.comm'

    base_export_name = 'run_base.export'
    export_opt_name = f'{now}-run_opt.export'
    export_opt_dir = os.path.join(wdir,'opt_files',export_opt_name)

    ######### CREATE COMM AND EXPORT FILES FOR THIS SIMULATION
    opt.create_comm(now,wdir,individual, epsilon_list,base_dir,base_comm_name,comm_opt_name)
    opt.create_export(wdir,base_dir,base_export_name,export_opt_name, comm_opt_name)
    
    ###### LAUNCHING THE SIMULATION
    run_file_base_name = 'lance_aster_base.sh'
    run_file_base_dir = os.path.join(base_dir,run_file_base_name)
    run_file_opt_name = f'{now}-lance_aster_opt.sh'
    run_file_opt_dir = os.path.join(wdir,'opt_files',run_file_opt_name)
    opt.create_run_file(wdir,run_file_base_dir, run_file_opt_dir ,export_opt_dir)

    opt.run_simu(run_file_opt_dir)
    
    # THE CODE CAN PROCEED ONLY WHEN RESULT IS AVAILABLE!!
    aux_val = 0
    fff = 1
    while aux_val==0:
        results_available = os.listdir(os.path.join(wdir,'results_ZHANG')) 
        if f'{now}-simu_{epsilon_list[-1]}_ZHANG.txt' in results_available:
            if fff==1:
                print('now:', now)
                print('SEARCHING FOR: ', f'{now}-simu_{epsilon_list[-1]}_ZHANG.txt')
                fff+=1
            print('FOUND!!')
            aux_val+=1    

    # 2nd step: extract results
    N_cycle = 48 # analyze simulation data to determine how many points in last cycle --- INSERT HERE THE CORRESPONDING VALUE (USER DEFINED)
    epsilon_aux, sigma_aux = opt.extract_data_simu(now,eps_str,res_dir,epsilon_list)
    epsilon_exp, sigma_exp = opt.extract_data_exp(exp_dir,filename)

    epsilon_ZHANG, sigma_ZHANG = {}, {}
    # extract only the points that are inside the final loop
    for key in list(epsilon_aux.keys()):
        epsilon_ZHANG[key] = epsilon_aux[key][-N_cycle:]
        sigma_ZHANG[key] = sigma_aux[key][-N_cycle:]



    # 3rd step: compute Root Mean Square Error
    # we are only going to use 4 points:
    # - max stress
    # - min stress
    # - 2 points corresponding to epsilon = 0%

    RMSE={}
    sigma_sel_exp, eps_sel_exp = {}, {}
    sigma_sel_ZHANG, eps_sel_ZHANG = {}, {}
    for key in list(epsilon_ZHANG.keys()):
        ####### 0% point with POSITIVE sigma #######

        # EXPERIMENTAL
        
        k=0
        epsilon_exp_aux = epsilon_exp
        sigma_exp_aux = sigma_exp
        epsilon_ZHANG_aux = epsilon_ZHANG
        sigma_ZHANG_aux = sigma_ZHANG
        while k==0:
            ind = opt.find_nearest(epsilon_exp_aux[key],0)
            if sigma_exp_aux[key][ind]<0:
                epsilon_exp_aux[key] = np.delete(epsilon_exp_aux[key],ind)
                sigma_exp_aux[key] = np.delete(sigma_exp_aux[key],ind)
            else:
                epsilon_exp_0_pos = epsilon_exp_aux[key][ind]
                sigma_exp_0_pos = sigma_exp_aux[key][ind]
                k=k+1
        # SIMULATION - must perform linear interpolation
        k=0
        eps_right,eps_left = [], []
        while k<2:
            ind = opt.find_nearest(epsilon_ZHANG_aux[key],epsilon_exp_0_pos)     
            if sigma_ZHANG_aux[key][ind]<0: #remove points where sigma < 0
                epsilon_ZHANG_aux[key] = np.delete(epsilon_ZHANG_aux[key],ind)
                sigma_ZHANG_aux[key] = np.delete(sigma_ZHANG_aux[key],ind)
            else:
                if epsilon_ZHANG_aux[key][ind]> epsilon_exp_0_pos:
                    if len(eps_right)==0:
                        eps_right.append(epsilon_ZHANG_aux[key][ind])
                        epsilon_ZHANG_right = epsilon_ZHANG_aux[key][ind]
                        sigma_ZHANG_right = sigma_ZHANG_aux[key][ind]
                        k=k+1
                        # after finding the point, we must exclude from the aux !!
                        epsilon_ZHANG_aux[key] = np.delete(epsilon_ZHANG_aux[key],ind)
                        sigma_ZHANG_aux[key] = np.delete(sigma_ZHANG_aux[key],ind)
                    else:
                        pass
                else:
                    if len(eps_left)==0:
                        eps_left.append(epsilon_ZHANG_aux[key][ind])
                        epsilon_ZHANG_left = epsilon_ZHANG_aux[key][ind]
                        sigma_ZHANG_left = sigma_ZHANG_aux[key][ind]
                        k=k+1
                        # after finding the point, we must exclude from the aux !!
                        epsilon_ZHANG_aux[key] = np.delete(epsilon_ZHANG_aux[key],ind)
                        sigma_ZHANG_aux[key] = np.delete(sigma_ZHANG_aux[key],ind)
                    else:
                        pass
            
        sigma_ZHANG_0_pos = sigma_ZHANG_left + (sigma_ZHANG_right - sigma_ZHANG_left)*((epsilon_exp_0_pos- epsilon_ZHANG_left)/(epsilon_ZHANG_right-epsilon_ZHANG_left))
        
        
        ####### 0% point with NEGATIVE sigma #######
        
        # EXPERIMENTAL
        k=0
        epsilon_exp_aux = epsilon_exp
        sigma_exp_aux = sigma_exp
        epsilon_ZHANG_aux = epsilon_ZHANG
        sigma_ZHANG_aux = sigma_ZHANG
        while k==0:
            ind = opt.find_nearest(epsilon_exp_aux[key],0)
            if sigma_exp_aux[key][ind]>0:
                epsilon_exp_aux[key] = np.delete(epsilon_exp_aux[key],ind)
                sigma_exp_aux[key] = np.delete(sigma_exp_aux[key],ind)
            else:
                epsilon_exp_0_neg = epsilon_exp_aux[key][ind]
                sigma_exp_0_neg = sigma_exp_aux[key][ind]
                k=k+1

        # SIMULATION - must perform linear interpolation
        k=0
        eps_right,eps_left = [], []
        while k<2:
            ind = opt.find_nearest(epsilon_ZHANG_aux[key],epsilon_exp_0_neg)
            if sigma_ZHANG_aux[key][ind]>0: #remove points where sigma > 0
                epsilon_ZHANG_aux[key] = np.delete(epsilon_ZHANG_aux[key],ind)
                sigma_ZHANG_aux[key] = np.delete(sigma_ZHANG_aux[key],ind)
            else:
                if epsilon_ZHANG_aux[key][ind]> epsilon_exp_0_neg:
                    if len(eps_right)==0:
                        eps_right.append(epsilon_ZHANG_aux[key][ind])
                        epsilon_ZHANG_right = epsilon_ZHANG_aux[key][ind]
                        sigma_ZHANG_right = sigma_ZHANG_aux[key][ind]
                        k=k+1
                        # after finding the point, we must exclude from the aux !!
                        epsilon_ZHANG_aux[key] = np.delete(epsilon_ZHANG_aux[key],ind)
                        sigma_ZHANG_aux[key] = np.delete(sigma_ZHANG_aux[key],ind)
                    else:
                        pass
                else:
                    if len(eps_left)==0:
                        eps_left.append(epsilon_ZHANG_aux[key][ind])
                        epsilon_ZHANG_left = epsilon_ZHANG_aux[key][ind]
                        sigma_ZHANG_left = sigma_ZHANG_aux[key][ind]
                        k=k+1
                        # after finding the point, we must exclude from the aux !!
                        epsilon_ZHANG_aux[key] = np.delete(epsilon_ZHANG_aux[key],ind)
                        sigma_ZHANG_aux[key] = np.delete(sigma_ZHANG_aux[key],ind)
                    else:
                        pass
        sigma_ZHANG_0_neg = sigma_ZHANG_left + (sigma_ZHANG_right - sigma_ZHANG_left)*((epsilon_exp_0_neg- epsilon_ZHANG_left)/(epsilon_ZHANG_right-epsilon_ZHANG_left))
        
        ####### maximum sigma #######

        # EXPERIMENTAL
        sigma_exp_max = max(sigma_exp[key])
        epsilon_exp_max = max(epsilon_exp[key])
        # SIMULATION
        sigma_ZHANG_max = max(sigma_ZHANG[key])
        epsilon_ZHANG_max = max(epsilon_ZHANG[key])

        ####### minimum sigma #######

        # EXPERIMENTAL
        sigma_exp_min = min(sigma_exp[key])
        epsilon_exp_min = min(epsilon_exp[key])
        # SIMULATION
        sigma_ZHANG_min = min(sigma_ZHANG[key])
        epsilon_ZHANG_min = min(epsilon_ZHANG[key])

        ##### TIME TO COMPUTE THE RMSE USING THESE 4 REFERENCE POINTS! #####
        sigma_exp_results = np.array([sigma_exp_min, sigma_exp_0_neg, sigma_exp_0_pos,sigma_exp_max])
        sigma_ZHANG_results = np.array([sigma_ZHANG_min, sigma_ZHANG_0_neg, sigma_ZHANG_0_pos,sigma_ZHANG_max])
        
        sigma_sel_exp[key]=([sigma_exp_min, sigma_exp_0_neg, sigma_exp_0_pos,sigma_exp_max])
        eps_sel_exp[key]=([epsilon_exp_min, epsilon_exp_0_neg, epsilon_exp_0_pos,epsilon_exp_max])
        
        sigma_sel_ZHANG[key]=([sigma_ZHANG_min, sigma_ZHANG_0_neg, sigma_ZHANG_0_pos,sigma_ZHANG_max])
        eps_sel_ZHANG[key]=([epsilon_ZHANG_min, epsilon_exp_0_neg, epsilon_exp_0_pos,epsilon_ZHANG_max])


        RMSE[key] = np.sqrt(((sigma_ZHANG_results - sigma_exp_results) ** 2).mean())

    RMSE_list = []
    for key in list(RMSE.keys()):
        RMSE_list.append(RMSE[key])
    return RMSE_list

################# OPTIMIZATION ##########################
import random
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from deap import base, creator, tools, algorithms
from concurrent.futures import ThreadPoolExecutor


# Number of objectives
NUM_OBJECTIVES = 3
# Number of decision variables
NUM_VARIABLES = 6
# Number of evaluations to run in parallel
NUM_EVALS_IN_PARALLEL = 10

# Create the problem as a minimization problem with three objectives
creator.create("FitnessMulti", base.Fitness, weights=(-1.0,) * NUM_OBJECTIVES)
creator.create("Individual", list, fitness=creator.FitnessMulti)

# Set up the toolbox
toolbox = base.Toolbox()

# Define ranges for each decision variable
ranges = [(50,150),(4,12),(120000,200000),(15000,30000),(1000,2000),(100,300)] # [R0, b, C1I, C2I, G10, G20 ]

# Attribute generator with specific ranges
def create_attr(index):
    low, up = ranges[index]
    return random.uniform(low, up)

# Initialize each decision variable within its range
def init_individual():
    return [create_attr(i) for i in range(NUM_VARIABLES)]

toolbox.register("individual", tools.initIterate, creator.Individual, init_individual)
toolbox.register("population", tools.initRepeat, list, toolbox.individual)

toolbox.register("select", tools.selNSGA2)  # Selection operator
toolbox.register("evaluate", compute_RMSE)  # Evaluation function

def adaptive_eta(generation, max_generations):
    initial_eta = 2.0
    final_eta = 20.0
    return initial_eta + (final_eta - initial_eta) * (generation / max_generations)

def evaluate_population(population):
    with ThreadPoolExecutor(max_workers=NUM_EVALS_IN_PARALLEL) as executor:
        futures = {executor.submit(toolbox.evaluate, ind): ind for ind in population}
        for future in futures:
            ind = futures[future]
            ind.fitness.values = future.result()
    return population


def main():
   
    pop = toolbox.population(n=20)  # Initialize population - GIVE POPULATION SIZE AS ARGUMENT!
    print("Sample individual:", pop[0])  # Print a sample individual
   
    # USER DEFINED VARIABLES #############
    ngen = 20  # Number of generations   #
    cxpb = 0.9  # Crossover probability  #
    mutpb = 0.1  # Mutation probability  #
   #######################################
   
    # Evaluate the initial population
    evaluate_population(pop)
    print("Initial evaluation done")

    for gen in range(ngen):
        
        eta = adaptive_eta(gen, ngen)
        # Crossover operator
        toolbox.register("mate", tools.cxSimulatedBinaryBounded, low=[low for low, up in ranges], up=[up for low, up in ranges], eta=eta)
        # Mutation operator
        toolbox.register("mutate", tools.mutPolynomialBounded, low=[low for low, up in ranges], up=[up for low, up in ranges], eta=eta, indpb=1.0/NUM_VARIABLES)  
        
        # Select the next generation individuals
        offspring = toolbox.select(pop, len(pop))
        offspring = list(map(toolbox.clone, offspring))
       
        # Apply crossover and mutation on the offspring
        for child1, child2 in zip(offspring[::2], offspring[1::2]):
            if random.random() < cxpb:
                toolbox.mate(child1, child2)
                del child1.fitness.values
                del child2.fitness.values
       
        for mutant in offspring:
            if random.random() < mutpb:
                toolbox.mutate(mutant)
                del mutant.fitness.values
       
        ## Evaluate the new individuals in parallel
        #invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
        #fitnesses = toolbox.map(toolbox.evaluate, invalid_ind)
        #for ind, fit in zip(invalid_ind, fitnesses):
        #    ind.fitness.values = fit


        # Evaluate the new individuals
        invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
        evaluate_population(invalid_ind)
        
        # Replace the current population with the offspring
        pop[:] = offspring
       
        # Gather all the fitnesses and print stats
        fits = np.array([ind.fitness.values for ind in pop])
        mean = np.mean(fits, axis=0)
        std = np.std(fits, axis=0)
       
        print(f"Generation {gen}: Min {np.min(fits, axis=0)}, Max {np.max(fits, axis=0)}, Avg {mean}, Std {std}")

    #pool.close()
    #pool.join()
   
    return pop

def find_closest_individual(objective_values):
    min_distance = float('inf')
    closest_individual_index = None
   
    for i, obj in enumerate(objective_values):
        distance = np.linalg.norm(obj)
        if distance < min_distance:
            min_distance = distance
            closest_individual_index = i
   
    return closest_individual_index

def extract_pareto_fronts(population):
    # Extract all Pareto fronts
    pareto_fronts = tools.sortNondominated(population, len(population), first_front_only=False)
   
    # Retrieve individuals that compose the Pareto front
    pareto_individuals = [ind for front in pareto_fronts for ind in front]
   
    return pareto_fronts, pareto_individuals

def save_to_file(pareto_fronts, pareto_individuals, population):
    with open('Results_optimization/pareto_fronts.txt', 'w') as pf_file:
        for i, front in enumerate(pareto_fronts):
            pf_file.write(f"Pareto Front {i+1}:\n")
            for ind in front:
                pf_file.write(f"{ind.fitness.values}\n")

    with open('Results_optimization/pareto_individuals.txt', 'w') as ind_file:
        for i, front in enumerate(pareto_fronts):
            ind_file.write(f"Pareto Front {i+1}:\n")
            for ind in front:
                ind_file.write(f"{ind}\n")

    with open('Results_optimization/all_individuals.txt', 'w') as all_file:
        for ind in population:
            all_file.write(f"Individual: {ind}, Fitness: {ind.fitness.values}\n")

def read_from_file(dir_individuals):
    import json
    # Read all individuals from file
    with open(dir_individuals) as f:
        lines = f.read().splitlines()
        str1 = 'Individual: '
        str2 = ', Fitness: '
        str3 = 'Fitness: '
        individuals=[]
        fitnesses = []
        for i in range(len(lines)):
            idx1 = lines[i].index(str1)
            idx2 = lines[i].index(str2)
            idx3 = lines[i].index(str3)
            
            individual = lines[i][idx1+len(str1):idx2]
            individual = json.loads(individual)
            individuals.append(individual)

            fitness = lines[i][idx3+len(str3)+1:-1]
            fitness = fitness.split()
            for j in range(len(fitness)):
                fitness[j]=fitness[j].strip(',')
            fitness = [float(x) for x in fitness]
            fitnesses.append(fitness)
            
            

    individuals = np.array(individuals)
    fitnesses = np.array(fitnesses)

    return individuals,fitnesses

def rank_pareto_fronts(decision_vars, objective_values):
    # Combine decision variables and objective values into DEAP individuals
    population = [creator.Individual(dec) for dec in decision_vars]
    for ind, obj in zip(population, objective_values):
        ind.fitness.values = tuple(obj)
   
    # Compute Pareto fronts
    pareto_fronts = tools.sortNondominated(population, len(population), first_front_only=False)
   
    # Create a dictionary to store the individuals and their objective values by rank
    pareto_dict = {}
    for rank, front in enumerate(pareto_fronts, start=1):
        rank_key = f"Rank {rank}"
        pareto_dict[rank_key] = {
            'individuals': np.array([ind for ind in front]),
            'objectives': np.array([list(ind.fitness.values) for ind in front])
        }
   
    return pareto_dict

def plot_pareto_fronts(pareto_dict):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    for key in pareto_dict.keys():
        ax.scatter(pareto_dict[key]['objectives'][:,0],pareto_dict[key]['objectives'][:,1],pareto_dict[key]['objectives'][:,2],label = str(key))
    closest_individual_index = find_closest_individual(pareto_dict['Rank 1']['objectives'])
    closest_individual = pareto_dict['Rank 1']['objectives'][closest_individual_index]
    ax.scatter(closest_individual[0], closest_individual[1], closest_individual[2], c='red', marker='x', s=100, label='Closest to Origin')

    # Adding labels and a legend
    ax.set_xlabel('Objective 1')
    ax.set_ylabel('Objective 2')
    ax.set_zlabel('Objective 3')
    ax.set_title('Pareto Front')
    ax.legend()

    # Save the plot to a file
    plt.savefig('Results_optimization/pareto_front.png')

    # Show the plot
    #plt.show()


if __name__ == "__main__":
    final_population = main()
   
    # Extract Pareto fronts and individuals
    pareto_fronts, pareto_individuals = extract_pareto_fronts(final_population)
   
    # Save Pareto fronts, individuals, and all individuals with their fitness values to files
    save_to_file(pareto_fronts, pareto_individuals, final_population)
   
    # Plot and save the Pareto front
    #plot_pareto_front(final_population, pareto_individuals)
   
    # Print the Pareto fronts and respective individuals
    for i, front in enumerate(pareto_fronts):
        print(f"Pareto Front {i+1}:")
        for ind in front:
            print(ind, ind.fitness.values)
   
    # Print the final population
    print("Final Population:")
    for ind in final_population:
        print(ind, ind.fitness.values)
    

  


