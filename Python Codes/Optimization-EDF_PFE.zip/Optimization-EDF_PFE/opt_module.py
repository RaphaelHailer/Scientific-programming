import numpy as np
import os
import sys
sys.path.append('/home/a02884/Salome_meca/Fichiers_de_commande_Theo/Optimization/')
from platypus import NSGAII, Problem, Real
import time
import pandas as pd

def create_comm(now, wdir, params, epsilon_list,base_dir,base_comm_name,comm_opt_name):
    '''

    CREATES THE .COMM FILE TO Run the simulation code for a set of Chaboche 
    parameters and a list of maximum deformations, corresponding with the 
    ones  experimental hysteresis data is available

    The current code (june 2024) is organized to only optimize parameters at 300°C

    - mater: material used
    'elastique', 'EDF_2008', 'LEPECHEUR', 'ZHANG' or 'ZHANGMem'

    - params: Chaboche parameters, given in the following form:
    [R0, b, C1I, C2I, G10, G20 ] 
    We are not going to change the young modulus nor the nu value, as it is agreed to be correct withing the Zhang parameters already

    - epsilon_list: list of maximum equivalent Von Mises strain for the hysteresis cycles
    ex: [0.001, 0.003, 0.005, ...]

    '''
    base_comm_dir = os.path.join(base_dir,base_comm_name) #location of base .comm file
    file = open(base_comm_dir,'r')
    lines = file.readlines()
    file.close()

    for i in range(len(lines)):
        if 'INSERT_params' in lines[i]:
            lines[i] = lines[i].replace('INSERT_params',str(params))
        elif 'INSERT_epsilon_list' in lines[i]:
            lines[i] = lines[i].replace('INSERT_epsilon_list',str(epsilon_list))
        elif 'INSERT_time' in lines[i]:
            lines[i] = lines[i].replace('INSERT_time',now)

    file = open(os.path.join(wdir,'opt_files',comm_opt_name),'w')
    for item in lines:
        file.write(item)
    file.close()

def create_export(wdir,base_dir,base_export_name,export_opt_name,comm_opt_name):
    base_export_dir = os.path.join(base_dir,base_export_name)
    comm_dir = os.path.join(wdir,'opt_files',comm_opt_name)
    file = open(base_export_dir,'r')
    lines = file.readlines()
    file.close()

    for i in range(len(lines)):
        if 'INSERT_comm_dir' in lines[i]:
            lines[i] = lines[i].replace('INSERT_comm_dir',comm_dir)

    file = open(os.path.join(wdir,'opt_files',export_opt_name),'w')
    for item in lines:
        file.write(item)
    file.close()


def create_run_file(wdir,run_file_base_dir, run_file_opt_dir ,export_opt_dir):
    file = open(run_file_base_dir,'r')
    lines = file.readlines()
    file.close()

    for i in range(len(lines)):
        if 'INSERT_EXPORT_DIR' in lines[i]:
            lines[i] = lines[i].replace('INSERT_EXPORT_DIR',export_opt_dir)

    file = open(run_file_opt_dir,'w')
    for item in lines:
        file.write(item)
    file.close()

def extract_data_exp(exp_dir,filename):
    ######### HIGH CYCLE (LC) ###########
    sigma_exp = {}
    epsilon_exp = {}
    # Base directory and filename
    
    # Construct the full path
    full_path = os.path.join(exp_dir, filename)

    xl_file = pd.ExcelFile(full_path)

    dfs = {sheet_name: xl_file.parse(sheet_name) 
            for sheet_name in xl_file.sheet_names}

    for key in list(dfs.keys()):
        epsilon_exp[key] = np.array((dfs[key]).loc[:,'Total Strain'])/100
        sigma_exp[key] = np.array((dfs[key]).loc[:,'Stress MPa'])
    return epsilon_exp, sigma_exp

def find_nearest(array, value):
        array = np.asarray(array)
        idx = (np.abs(array - value)).argmin()
        return idx

def extract_data_simu(now,eps_str,res_dir,epsilon_list):
    simu_ZHANG = {}
    epsilon_ZHANG={}; sigma_ZHANG = {}
    for i in range(len(eps_str)):
        #with open(os.path.join(res_dir,f'{now}-simu_{epsilon_list[i]}_ZHANG.txt')) as f:
        #    a = f.read().splitlines()
        #    for l in range(len(a)):
        #        a[l] = a[l].split()
        #    for l in range(len(a)):
        #        for m in range(len(a[0])):
        #            a[l][m] = float(a[l][m])
        #a = np.transpose(np.array(a))
        #simu_ZHANG[eps_str[i]] = a
        simu_ZHANG[eps_str[i]] = pd.read_csv(os.path.join(res_dir,f'{now}-simu_{epsilon_list[i]}_ZHANG.txt'), delim_whitespace=True,header = None)
        simu_ZHANG[eps_str[i]]= simu_ZHANG[eps_str[i]].astype(float)
        simu_ZHANG[eps_str[i]] = simu_ZHANG[eps_str[i]].to_numpy()
        #simu_ZHANG[eps_str[i]] = np.loadtxt(os.path.join(res_dir,f'{now}-simu_{epsilon_list[i]}_ZHANG.txt'))
        # np.genfromtxt(os.path.join(res_dir,f'{now}-simu_{epsilon_list[i]}_ZHANG.txt'),invalid_raise = False)
        simu_ZHANG[eps_str[i]] = np.transpose(simu_ZHANG[eps_str[i]])
        epsilon_ZHANG[eps_str[i]] = simu_ZHANG[eps_str[i]][:,0]
        sigma_ZHANG[eps_str[i]] = simu_ZHANG[eps_str[i]][:,1]
    return epsilon_ZHANG, sigma_ZHANG

def run_simu(run_file):
    os.system('sbatch '+run_file)

